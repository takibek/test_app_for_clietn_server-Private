package com.javapapers.application1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

public class MainActivity extends AppCompatActivity {



    int x=0;
    ServerSocket serverSocket;
    private static final String TAG = "SocketServerActivity";
    Button send,server,stop;
    TextView port,st;
    String s,receivedData ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_main );


        send=(Button) findViewById( R.id.send );
        server=(Button) findViewById( R.id.server );
        stop=(Button) findViewById( R.id.stops);
        port=(TextView) findViewById( R.id.port );
        st=(TextView) findViewById( R.id.st );




        stop.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                  st.setText(receivedData);

            }
        } );
        send.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText( getApplicationContext(),"clietn start",Toast.LENGTH_LONG ).show();

                startSocketClient( Integer.parseInt( port.getText().toString() ) );
            }
        } );
        server.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText( getApplicationContext(),"sever start",Toast.LENGTH_LONG ).show();
                Thread serverThread = new Thread(new ServerThread());
                serverThread.start();
            }
        } );
    }
    private class ServerThread implements Runnable {

        @Override
        public void run() {
            try {
                 serverSocket = new ServerSocket(Integer.parseInt( port.getText().toString() ));
                Log.d(TAG, "Server is listening on port " + Integer.parseInt( port.getText().toString() ));



                while (true) {

                    Socket clientSocket = serverSocket.accept();

                    Log.d(TAG, "Accepted connection from " + clientSocket.getInetAddress());

                    // Handle incoming data from the client
                    InputStream inputStream = clientSocket.getInputStream();
                    System.out.println("server receives:"+inputStream);
                    byte[] buffer = new byte[1024];
                    int bytesRead;


                    while ((bytesRead = inputStream.read(buffer)) != -1) {
                         receivedData = new String(buffer, 0, bytesRead);

                        System.out.println("server receives:"+receivedData);
                        new DataToSend().sendDataToServer( receivedData);
                        // Process the received data here

                        // Send a response back to the client (if needed)
                        OutputStream outputStream = clientSocket.getOutputStream();
                        String response = "Server received your data.";
                        outputStream.write(response.getBytes());

                    }

                    System.out.println("before close");

                    // Close the client socket
                    clientSocket.close();
               }


            } catch (IOException e) {

                e.printStackTrace();
            }


        }
    }


//-------------------------------------------------------------------
    private void startSocketClient(int SERVER_PORT_NUMBER) {

        Timer timer = new Timer();
        timer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                try {
                   // the x is used just to know the clietn number
                    x++;


                    String randomString = generateRandomAlphaString();
                    System.out.println("clients sends:"+randomString);

                    // Define the server's IP address and port number
                    String serverIp = "127.0.0.1";
                    int serverPort =SERVER_PORT_NUMBER;

                    // Create a socket connection to the server
                    Socket socket = new Socket(serverIp, serverPort);

                    if (socket.isConnected()){
                        System.out.println(" client number "+x+" is connected to the server");
                    }else{ System.out.println(" not connected to the server");}
                    // Get an output stream to send data to the server
                    OutputStream outputStream = socket.getOutputStream();
                    DataOutputStream dataOutputStream = new DataOutputStream(outputStream);

                    // Generate a random string with only alpha characters
                  //  String randomString = generateRandomAlphaString();

                    // Send the random string to the server
                    dataOutputStream.writeUTF(randomString);
                    //System.out.println("clients sends:"+randomString);
                    // Close the socket
                    socket.close();
                } catch (IOException e) {
                    e.printStackTrace();

                }
            }
        }, 0, 2000); // Send data every 2 seconds
    }

    // Method to generate a random alpha string
    private String generateRandomAlphaString() {
        String characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        StringBuilder randomString = new StringBuilder();
        Random random = new Random();

        for (int i = 0; i < 10; i++) { // Generate a random 10-character string
            char randomChar = characters.charAt(random.nextInt(characters.length()));
            randomString.append(randomChar);
        }

        return randomString.toString();
    }

}