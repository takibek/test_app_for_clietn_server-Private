package com.javapapers.application1;

import java.io.DataOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;

public class DataToSend {
    public void sendDataToServer(String dataToSend) {
        try {
            // Define the server URL where your PHP script is hosted
            URL url = new URL("https://testclientserver.000webhostapp.com/");

            // Open a connection to the URL
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();

            // Set the HTTP request method to POST
            connection.setRequestMethod("POST");

            // Enable input and output streams
            connection.setDoInput(true);
            connection.setDoOutput(true);

            // Create a data output stream to send data as bytes
            OutputStream os = connection.getOutputStream();
            DataOutputStream writer = new DataOutputStream(os);

            // Write your data to the output stream
            writer.writeBytes("value="+dataToSend);

            // Flush and close the output stream
            writer.flush();
            writer.close();

            // Get the HTTP response code
            int responseCode = connection.getResponseCode();

            // Handle the response code and any further processing
            if (responseCode == HttpURLConnection.HTTP_OK) {
                // Data sent successfully
            } else {
                // Handle HTTP error
            }

            // Close the connection
            connection.disconnect();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
